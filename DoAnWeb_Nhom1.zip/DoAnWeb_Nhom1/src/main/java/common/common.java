package common;

public class common {
	public static String EMAIL_ADMIN = "admin@gmail.com";

	public static String jdbcURL = "jdbc:mysql://127.0.0.1:3306/doanweb?useSSL=false";
	public static String jdbcUsername = "root";
	public static String jdbcPassword = "passwordmysql";
	public static String jdbcDriver = "com.mysql.jdbc.Driver";
}
